package galaxy;

import javax.swing.ImageIcon;
import java.awt.Rectangle;
import java.util.Random;

public class Alien {
	final int PANEL_WIDTH = 500;
	final int PANEL_HEIGHT = 500;
	private int dx;						// Moving direction
	private int x; 						// Location on the x-axis
	private int y;						// Location on the y-axis
	private ImageIcon image;
	private Random random;
	private int changeDirectionDelay; 	// Delay for movement x-axis
	private int changeDirectionCounter; // Counts how many times the method had been called
    private int moveDownCounter = 0;    // Counter for moving down
    private int moveDownDelay = 120;	// Delay for moving down 

    public Alien(int x, int y) {
        this.x = x;
        this.y = y;
        dx = 1;  // Set initial direction to right
        this.changeDirectionDelay = 100; 
        random = new Random();
        image = new ImageIcon(new ImageIcon("aa.png").getImage().getScaledInstance(40, 30,  java.awt.Image.SCALE_SMOOTH));
    }

    public void move() {
        changeDirectionCounter++;
        if (changeDirectionCounter >= changeDirectionDelay) {
            if (random.nextInt(100) < 10) {
                dx = -dx;
            }
            changeDirectionCounter = 0;
        }
        x += dx;

        // wrapping of container
        if (x + image.getIconWidth() < 0) {
            x = PANEL_WIDTH - image.getIconWidth()/2;
        } else if (x - image.getIconWidth()/2 > PANEL_WIDTH) {
            x = 0 - image.getIconWidth()/2;
        }
        //move down delay
        moveDownCounter++;
        if (moveDownCounter >= moveDownDelay) {
            y += 40;
            moveDownCounter = 0;
        }
    }


    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public ImageIcon getImage() {
        return image;
    }

    public Rectangle getBounds() {
        return new Rectangle(x, y, image.getIconWidth(), image.getIconHeight());
    }
}
