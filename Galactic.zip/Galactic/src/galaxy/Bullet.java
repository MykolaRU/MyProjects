package galaxy;

import java.awt.Rectangle;

import javax.swing.ImageIcon;

public class Bullet {
    private int x;
    private int y;
    private ImageIcon image;

    public Bullet(int x, int y) {
        this.x = x;
        this.y = y;
        image = new ImageIcon(new ImageIcon("bullet.png").getImage().getScaledInstance(10, 20,  java.awt.Image.SCALE_SMOOTH));
    }

    public Rectangle getBounds() {
        return new Rectangle(x, y, image.getIconWidth(), image.getIconHeight());
    }
    
    public void move() {
        // Update position of bullet, goes up
        y=y-2;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public ImageIcon getImage() {
        return image;
    }
}
