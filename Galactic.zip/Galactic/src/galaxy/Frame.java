package galaxy;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;

public class Frame extends JFrame implements ActionListener{
	
	final int FRAME_WIDTH = 500;
	final int FRAME_HEIGHT = 500;
	JButton play;
	LaunchPadCover cover;
	
	public Frame() {
		this.setTitle("Galactic");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(FRAME_WIDTH,FRAME_HEIGHT);
		this.setLayout(null);
		this.getContentPane().setBackground(Color.black);
		
		cover = new LaunchPadCover();
		 cover.setBounds(0, 0, FRAME_WIDTH, FRAME_HEIGHT);
		this.add(cover);
	}
	


	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource()==play) {
			GameContent game = new GameContent();
			game.setVisible(true);
	        this.dispose();  	
		}
	}
}
