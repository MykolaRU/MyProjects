package galaxy;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.Timer;


public class GameContent extends JPanel {
	
	   private int score;  						// Variable for game score
	    private Rocket rocket;  				// Rocket object
	    private static List<Alien> aliens;  	// List of Alien objects
	    private static List<Bullet> bullets;  	// List of Bullet objects
	    private Timer timer, alienSpawnTimer;   // Timers for game loop and alien spawning
	    private Random random;  				// Random object for spawning aliens
    private ImageIcon heartImage = 				//Lives Image
    		new ImageIcon(new ImageIcon("heart.png")
    				.getImage().getScaledInstance(15, 15,  java.awt.Image.SCALE_SMOOTH));


    public GameContent() {
    	score = 0;
    	
        setFocusable(true);
        rocket = new Rocket();
        aliens = new ArrayList<>();
        bullets = new ArrayList<>();
        random = new Random();
        setBackground(Color.BLACK);

        // Add a KeyListener for rocket controls
        addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent e) {
                rocket.keyPressed(e);
            }        
            public void keyReleased(KeyEvent e) {
                rocket.keyReleased(e);
            }
        });

        // Game loop/update
        timer = new Timer(1000/60, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                update();
                repaint();
            }
        });
        timer.start();

        // Alien spawn loop
        alienSpawnTimer = new Timer(2000, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                spawnAlien();
            }
        });
        alienSpawnTimer.start();
    }
    

    public static void addBullet(Bullet bullet) {
        bullets.add(bullet);
    }
    
    
  //---------------------------------------------------------  >
    private void spawnAlien() {
        int x = random.nextInt(400);
        int y = 0;
        aliens.add(new Alien(x, y));
    }
    
  //--------------------------------------------------------->
    private void update() {
        // Update positions of rocket, aliens, and bullets
        rocket.move();
        for (Alien alien : aliens) {
            alien.move();
        }
        for (Bullet bullet : bullets) {
            bullet.move();
        }

        // Check for collisions
        checkCollisions();
        if (rocket.getLives() <= 0) {
            stopGame();
        }
    }
    
//--------------------------------------------------------->
    private void checkCollisions() {
        // Check for collisions between aliens and bullets
        Iterator<Alien> alienIterator = aliens.iterator();
        while (alienIterator.hasNext()) {		//traverses the list of aliens
            Alien alien = alienIterator.next();
            Iterator<Bullet> bulletIterator = bullets.iterator();
            
            while (bulletIterator.hasNext()) { 	//traverses the list of bullets
                Bullet bullet = bulletIterator.next();
                if (alien.getBounds().intersects(bullet.getBounds())) {
                    alienIterator.remove();
                    bulletIterator.remove();
                    score++;
                }
            }

            // Check for collisions between aliens and the rocket
            if (alien.getBounds().intersects(rocket.getBounds())) {
                alienIterator.remove();
                rocket.loseLife();
                // TODO: Check for game over
                if (rocket.getLives() <= 0) {
                    stopGame();
                } 
            }
        }
    }

  //--------------------------------------------------------->

    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        // Draw the rocket
        g.drawImage(rocket.getImage().getImage(), rocket.getX(), rocket.getY(), null);

        // Draw the aliens
        for (Alien alien : aliens) {
            g.drawImage(alien.getImage().getImage(), alien.getX(), alien.getY(), null);
        }

        // Draw the bullets
        for (Bullet bullet : bullets) {
            g.drawImage(bullet.getImage().getImage(), bullet.getX(), bullet.getY(), null);
        }

        // Draw lives
        for (int i = 0; i < rocket.getLives(); i++) {
            g.drawImage(heartImage.getImage(), i * 15, 5, null);
            
        // SCORE            
            String scoreText = "Score: " + score;
            int scoreX = getWidth() - g.getFontMetrics().stringWidth(scoreText) - 5; // Right-aligned
            int scoreY = getHeight() - 5; // 5 pixels from the bottom
            g.setColor(Color.WHITE);
            g.drawString(scoreText, scoreX, scoreY);
        }
    }
    
   //----------------------------------------------------->
    private void stopGame() {
        // Stop the timers to freeze the game
        timer.stop();
        alienSpawnTimer.stop();
    }

}
