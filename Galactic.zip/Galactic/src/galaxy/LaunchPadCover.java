package galaxy;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.Timer;

public class LaunchPadCover extends JPanel implements ActionListener {
    
    final int PANEL_WIDTH = 500;  		// Width of the panel
    final int PANEL_HEIGHT = 500;  		// Height of the panel
    JButton play;  						// Button to start the game
    JLabel welcome; 					// Label for welcome message
    ImageIcon alien, background;  		// Icons for alien and background
    Timer timer;  						// Timer for animation
    int X_VELOCITY = 1, Y_VELOCITY = 1; // Velocity of the alien image
    int x=10, y=10;  					// Initial position of the alien image
    
    public LaunchPadCover() {
        // Initializing images and scaling them
        alien = new ImageIcon(new ImageIcon("aa.png").getImage().getScaledInstance(80, 60,  java.awt.Image.SCALE_SMOOTH));
        background = new ImageIcon(new ImageIcon("space1.jpg").getImage().getScaledInstance(PANEL_WIDTH, PANEL_HEIGHT,  java.awt.Image.SCALE_SMOOTH));
        timer = new Timer(10,this);  	// Setting timer for action events
        timer.start();

        CreatePlaybutton();  			// Method to create play button
        CreateWelcomeLabel();  			// Method to create welcome label
        
        JPanel container = new JPanel(new GridBagLayout());  	// Container panel with GridBagLayout
        container.setOpaque(false);
        
        GridBagConstraints gbc = new GridBagConstraints();  	// Constraints for layout
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.anchor = GridBagConstraints.CENTER;
        
        container.add(welcome, gbc);  							// Adding welcome label to container
        container.add(play, gbc); 							    // Adding play button to container
        
        this.setLayout(new GridBagLayout());  					// Setting layout for this panel
        this.add(container);  									// Adding container to this panel
    }
    
    public void CreateWelcomeLabel() {
        // Creating and styling welcome label
        welcome = new JLabel("WELCOME!");
        welcome.setForeground(Color.RED);
        welcome.setFont(new Font("Arial", Font.BOLD, 24));
    }

    public void CreatePlaybutton() {
        // Creating and styling play button
        play = new JButton("Play");
        play.setBackground(new Color(178,102,250));
        play.setFocusable(false);
        play.addActionListener(this);
        play.setVisible(true);
    }
    
    public void paintComponent(Graphics g) {
        // Method to draw components on the panel
        super.paintComponent(g);
        if(background != null) {
            g.drawImage(background.getImage(),0,0,null);  		// Drawing background
        }
        if(alien != null) {
            g.drawImage(alien.getImage(),x,y,null);  			// Drawing alien
        }
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        // Handling action events
        if(e.getSource() == play) {
            // If play button is clicked, a new game window is created
            JFrame gameFrame = new JFrame("Galactic Game");
            gameFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            gameFrame.setSize(PANEL_WIDTH, PANEL_HEIGHT);

            GameContent game = new GameContent();  				// Creating new game content
            gameFrame.add(game);
            gameFrame.setVisible(true);

            ((Window) getRootPane().getParent()).dispose();  	// Closing the current window
        } 
        else {
            // Handling alien movement
            if(x >= PANEL_WIDTH - alien.getIconWidth() || x < 0) {
                X_VELOCITY = X_VELOCITY * -1;
            }
            x = x + X_VELOCITY;

            if(y >= PANEL_HEIGHT - alien.getIconHeight() || y < 0) {
                Y_VELOCITY = Y_VELOCITY * -1;
            }
            y = y + Y_VELOCITY;
            repaint();  										// Repainting the panel
        }
    }

}
