package galaxy;

import java.awt.Rectangle;
import java.awt.event.KeyEvent;
import javax.swing.ImageIcon;

public class Rocket {
	 final int PANEL_WIDTH = 500;       // Width of the game panel
	    final int PANEL_HEIGHT = 500;   // Height of the game panel
	    private int dx;                 // Horizontal movement increment
	    private int x;                  // Current horizontal position of the rocket
	    private int y;                  // Current vertical position of the rocket
	    private ImageIcon image;        // Image representing the rocket
	    private int lives = 3;          // Number of lives for the rocket
	    private long lastShotTime;      // Timestamp of the last shot for rate limiting


    public Rocket() {
        // Initialize position (x, y) 
        x = 200;  
        y = 370;  
        dx = 0;
        image = new ImageIcon("rocket2.png");
       // image = new ImageIcon(new ImageIcon("rocket2.png").getImage().getScaledInstance(100, 100,  java.awt.Image.SCALE_SMOOTH));
    }
    
    public Rectangle getBounds() {
        return new Rectangle(x, y, image.getIconWidth(), image.getIconHeight());
    }
    
    public void move() {
        x += dx;

        // wrapping behavior for Rocket
        if (x + image.getIconWidth() < 0) {
            x = PANEL_WIDTH - image.getIconWidth()/2;
        } else if (x - image.getIconWidth()/2 > PANEL_WIDTH) {
            x = 0 - image.getIconWidth()/2;
        }
    }


    public void keyPressed(KeyEvent e) {
        switch (e.getKeyCode()) {
            case KeyEvent.VK_A:dx = -3;     //A button for LEFT
                break;
            case KeyEvent.VK_D:dx = 3;      //D button for RIGHT
                break;
            case KeyEvent.VK_SPACE:         //SPACe to shoot plus offset
                long currentTime = System.currentTimeMillis();
                if (currentTime - lastShotTime >= 650) {  			// Cool down for shooting
                    int bulletX = x + image.getIconWidth() / 2-5;
                    int bulletY = y + image.getIconHeight() / 2-10;
                    GameContent.addBullet(new Bullet(bulletX, bulletY));
                    lastShotTime = currentTime;
                }
                break;
        }
    }


    public void keyReleased(KeyEvent e) {  //When key is released, stops the movement
        switch (e.getKeyCode()) {
            case KeyEvent.VK_A:
            case KeyEvent.VK_D:
                dx = 0;
                break;
        }
    }
    
    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public ImageIcon getImage() {
        return image;
    }

    public int getLives() {
        return lives;
    }
    
    public void loseLife() {
        lives--;
    }
    
}
