/**
 * 
 */
/**
 * 
 */
module Galactic {
	requires java.desktop;
}