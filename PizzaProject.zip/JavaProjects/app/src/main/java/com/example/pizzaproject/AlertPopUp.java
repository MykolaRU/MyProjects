package com.example.pizzaproject;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;

public class AlertPopUp {

    public static void showErrorDialog(Context context, String errorMessage) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Error")
                .setMessage(errorMessage)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        // Can implement the action after ok is clicked HERE --
                        dialog.dismiss();
                    }
                })
                .show();
    }

}

