package com.example.pizzaproject;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class BuildYourOwnActivity extends AppCompatActivity {

    private Spinner sizeSpinner;
    private RecyclerView mainToppingList, addedList;
    private RadioGroup sauceRadioGroup;
    private RadioButton tomatoSauceRadioButton, alfredoSauceRadioButton;
    private CheckBox extraCheeseCheckBox, extraSauceCheckBox;
    private Button addButton, removeButton, addToOrderButton;
    private TextView priceTextView;
    private ImageView pizzaImageView;
    private List<String> selectedToppings;
    private List<String> allToppings = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.buildyourown);
        // Initialize everything
        initilize();
        // Setup listeners for buttons
        setupButtonListeners();
    }


    private void initilize(){
        // Initialize all components based on their IDs
        sizeSpinner = findViewById(R.id.sizeSpinner2);

        // Initialize RadioGroup and RadioButtons for sauce
        sauceRadioGroup = findViewById(R.id.radioGroup);
        tomatoSauceRadioButton = findViewById(R.id.tomatoSauceRB);
        alfredoSauceRadioButton = findViewById(R.id.alfredoSauceRB);

        // Initialize Checkboxes for extra options
        extraCheeseCheckBox = findViewById(R.id.extraCheese2);
        extraSauceCheckBox = findViewById(R.id.extraSauce2);

        // Initialize RecyclerViews for the topping lists
        mainToppingList = findViewById(R.id.mainToppingList);     // List of all toppings
        addedList = findViewById(R.id.addedList);                 // List of added toppings

        // Initialize Buttons
        addButton = findViewById(R.id.addButton);
        removeButton = findViewById(R.id.removeButton);
        addToOrderButton = findViewById(R.id.addToOrder2);

        // Initialize TextView for the price
        priceTextView = findViewById(R.id.priceView);

        // Initialize ImageView for pizza image
        pizzaImageView = findViewById(R.id.imageView);

        // Setup the Spinner with ArrayAdapter for sizes
        ArrayAdapter<CharSequence> sizeAdapter = ArrayAdapter.createFromResource(this,
                R.array.pizza_sizes,                // This array is defined in strings.xml
                android.R.layout.simple_spinner_item);
        sizeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sizeSpinner.setAdapter(sizeAdapter);


        // Setup the RecyclerView with LayoutManager and Adapter
        // Assuming you have a ToppingsAdapter defined elsewhere
        mainToppingList.setLayoutManager(new LinearLayoutManager(this));
        mainToppingList.setAdapter(new ToppingsAdapter(allToppings, this::onToppingSelected));

        addedList.setLayoutManager(new LinearLayoutManager(this));
        addedList.setAdapter(new ToppingsAdapter(allToppings, topping -> {
            // Do nothing on click
        }));


        // INITIALIZE MainToppingList
        for (Topping topping : Topping.values()) {
            allToppings.add(topping.name());
        }
        mainToppingList.setAdapter(new ToppingsAdapter(allToppings, this::onToppingSelected));

        selectedToppings = new ArrayList<>();                                                       // Creates new arrayList for added toppings
        addedList.setAdapter(new ToppingsAdapter(selectedToppings, topping -> {}));                 // Sets up an adapter for addedList

        updatePrice();
    }


    private void updatePrice(){
        sizeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                calculatePrice();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        sauceRadioGroup.setOnCheckedChangeListener((group, checkedId) -> calculatePrice());
        extraCheeseCheckBox.setOnCheckedChangeListener((buttonView, isChecked) -> calculatePrice());
        extraSauceCheckBox.setOnCheckedChangeListener((buttonView, isChecked) -> calculatePrice());
    }


    private void onToppingSelected(String topping) {
        selectedToppings.add(topping);
        addedList.getAdapter().notifyDataSetChanged();
    }


    // Listeners for Buttons
    private void setupButtonListeners() {
        addButton.setOnClickListener(v -> {
            ToppingsAdapter mainAdapter = (ToppingsAdapter) mainToppingList.getAdapter();
            int selectedPosition = mainAdapter.getSelectedPosition();
            if (selectedPosition != -1) {
                String selectedTopping = allToppings.remove(selectedPosition);
                selectedToppings.add(selectedTopping);
                mainAdapter.notifyDataSetChanged();
                ((ToppingsAdapter) addedList.getAdapter()).resetSelection();
                calculatePrice();
            } else {
                Toast.makeText(BuildYourOwnActivity.this, "Please select a topping to add.", Toast.LENGTH_SHORT).show();
            }
        });

        removeButton.setOnClickListener(v -> {
            ToppingsAdapter addedAdapter = (ToppingsAdapter) addedList.getAdapter();
            int selectedPosition = addedAdapter.getSelectedPosition();
            if (selectedPosition != -1) {
                String selectedTopping = selectedToppings.remove(selectedPosition);
                allToppings.add(selectedTopping); // Add back to allToppings
                addedAdapter.notifyDataSetChanged();
                ((ToppingsAdapter) mainToppingList.getAdapter()).notifyDataSetChanged();
                calculatePrice();
                addedAdapter.resetSelection(); // Clear selection in addedList
            } else {
                Toast.makeText(BuildYourOwnActivity.this, "Please select a topping to remove.", Toast.LENGTH_SHORT).show();
            }
        });

        addToOrderButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addToOrder();
            }
        });

    }



    private void calculatePrice(){
        // Retrieve selections from your UI components
        Size size = getSize(); // Get size from spinner
        if (size==null) {
            AlertPopUp.showErrorDialog(BuildYourOwnActivity.this, "Something went wrong! Size error");
            return;
        }

        Sauce sauce = getSauce();               // Determines the selected sauce
        boolean extraSauce = extraSauceCheckBox.isChecked();
        boolean extraCheese = extraCheeseCheckBox.isChecked();

        ArrayList<Topping> selectedToppingsEnums = new ArrayList<>();                            // Creating a new array list to convert selectedToppings to TOPPING enums
        for (String toppingString : selectedToppings) {
            try {
                Topping topping = Topping.valueOf(toppingString.toUpperCase());
                selectedToppingsEnums.add(topping);
            } catch (IllegalArgumentException e) {
                AlertPopUp.showErrorDialog(BuildYourOwnActivity.this, "Something went wrong! Toppings error");
            }
        }
            // Creates pizza
            Pizza pizza = PizzaMaker.createPizza("build your own", size, sauce, extraSauce, extraCheese, selectedToppingsEnums);       // Create pizza with the selected options

            double price = pizza.getPrice();
            priceTextView.setText(String.format("$%.2f", price));
    }



    private void addToOrder(){
        // Retrieve selections from your UI components
        Size size = getSize(); // Get size from spinner
        if (size==null) {
            AlertPopUp.showErrorDialog(BuildYourOwnActivity.this, "Something went wrong! Size error");
            return;
        }

        Sauce sauce = getSauce();               // Determines the selected sauce
        boolean extraSauce = extraSauceCheckBox.isChecked();
        boolean extraCheese = extraCheeseCheckBox.isChecked();

        ArrayList<Topping> selectedToppingsEnums = new ArrayList<>();                            // Creating a new array list to convert selectedToppings to TOPPING enums
        for (String toppingString : selectedToppings) {
            try {
                Topping topping = Topping.valueOf(toppingString.toUpperCase());
                selectedToppingsEnums.add(topping);
            } catch (IllegalArgumentException e) {
                AlertPopUp.showErrorDialog(BuildYourOwnActivity.this, "Something went wrong! Toppings error");
            }
        }

        if (selectedToppings.size() < 3) {
            // Show alert if not enough toppings
            AlertPopUp.showErrorDialog(BuildYourOwnActivity.this, "Please select at least 3 toppings!");
            return;
        } else {
            // Create the pizza using your logic
            Pizza pizza = PizzaMaker.createPizza("build your own", size, sauce, extraSauce, extraCheese, selectedToppingsEnums);       // Create pizza with the selected options
            double price = pizza.getPrice();

            priceTextView.setText(String.format("$%.2f", price));


            Order currentOrder = SharedOrderSingleton.getInstance().getCurrentOrder();
            currentOrder.addPizza(pizza); // Add pizza to the shared order
            Toast.makeText(BuildYourOwnActivity.this, "Success! Pizza added to Order #" + currentOrder.getOrderNumber(), Toast.LENGTH_SHORT).show();
        }
    }

    // Retrieves Size from the dropbox
    private Size getSize(){
        Size size = null;
        String sizeString = sizeSpinner.getSelectedItem().toString().toUpperCase();
        if(sizeString.equals( "SMALL")) return Size.SMALL;
        else if(sizeString.equals("MEDIUM")) return Size.MEDIUM;
        else if(sizeString.equals("LARGE")) return Size.LARGE;
        else return size;
    }

    private Sauce getSauce(){
        int selectedId = sauceRadioGroup.getCheckedRadioButtonId();
        RadioButton selectedRadioButton = findViewById(selectedId);         // Finding sauce by id

        if (selectedRadioButton != null) {
            String sauceType = selectedRadioButton.getText().toString();
            if ( sauceType.equals("alfredo sauce")) return Sauce.ALFREDO;
            else if(sauceType.equals("tomato sauce")) return Sauce.TOMATO;
        }
        return null;
    }
}
