package com.example.pizzaproject;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.textfield.TextInputEditText;

import java.util.ArrayList;

public class CurrentOrderActivity extends AppCompatActivity {
    private ArrayList<String> pizzaList;
    private RecyclerView orderList;
    private TextView orderNumber;
    private TextInputEditText subtotal;
    private TextInputEditText salesTax;
    private TextInputEditText orderTotal;
    private Button placeOrderButton;
    private Button removeButton;
    private PizzaAdapter pizzaAdapter;
    private Order currentOrder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.currentorder);
        pizzaList = new ArrayList<>();
        // Initializes all components
        initializeViews();
        initialize();
    }

    private void initializeViews() {
        orderList = findViewById(R.id.orderList);
        orderNumber = findViewById(R.id.orderNumber);
        subtotal = findViewById(R.id.subtotal);
        salesTax = findViewById(R.id.salesTax);
        orderTotal = findViewById(R.id.orderTotal);
        placeOrderButton = findViewById(R.id.placeOrderButton);
        removeButton = findViewById(R.id.removeButton2);

        // Places order and updates the screen
        placeOrderButton.setOnClickListener(view -> {
            SharedOrderSingleton.getInstance().finalizeCurrentOrder();
            Toast.makeText(CurrentOrderActivity.this, "Success. Order #" + currentOrder.getOrderNumber() + " has been palced!", Toast.LENGTH_SHORT).show();
            pizzaList.clear();
            pizzaAdapter.updatePizzaList(pizzaList); // Refresh the adapter
            currentOrder = null;
            orderNumber.setText("");
            subtotal.setText("");
            salesTax.setText("");
            orderTotal.setText("");

        });

        removeButton.setOnClickListener(view -> removeItem());
    }

    private void initialize() {
        currentOrder = SharedOrderSingleton.getInstance().getCurrentOrder();
        if (currentOrder != null) {
            orderNumber.setText(String.valueOf(currentOrder.getOrderNumber()));

            ArrayList<String> pizzaList = new ArrayList<>();
            for (Pizza pizza : currentOrder.getPizzas()) {
                pizzaList.add(pizza.toString());
            }

            pizzaAdapter = new PizzaAdapter(pizzaList);
            orderList.setLayoutManager(new LinearLayoutManager(this));
            orderList.setAdapter(pizzaAdapter);

            calculateTotalPrice();
        }
    }

    private void removeItem() {
        int selectedPosition = pizzaAdapter.getSelectedPosition();
        if (selectedPosition != -1 && currentOrder != null) {
            currentOrder.removePizzaAt(selectedPosition);

            // Update pizzaList and refresh the adapter
            pizzaList.clear();
            for (Pizza pizza : currentOrder.getPizzas()) {
                pizzaList.add(pizza.toString());
            }
            pizzaAdapter.updatePizzaList(pizzaList); // Use the updatePizzaList method to refresh the adapter

            calculateTotalPrice();
        } else {
            Toast.makeText(CurrentOrderActivity.this, "Please select a pizza to remove.", Toast.LENGTH_SHORT).show();
        }
    }


    private void calculateTotalPrice() {
        double subtotalValue = currentOrder.getTotalPrice();
        double salesTaxValue = subtotalValue * 0.06625;
        double totalValue = subtotalValue + salesTaxValue;

        subtotal.setText(String.format("$%.2f", subtotalValue));
        salesTax.setText(String.format("$%.2f", salesTaxValue));
        orderTotal.setText(String.format("$%.2f", totalValue));
    }
}
