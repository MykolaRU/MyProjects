package com.example.pizzaproject;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_menu);

        CardView specialtyCard = findViewById(R.id.specialtyCard);
        CardView buildCard = findViewById(R.id.buildCard);
        CardView currentOrderCard = findViewById(R.id.currentOrderCard);
        CardView storeOrderCard = findViewById(R.id.storeOrderCard);

        specialtyCard.setOnClickListener(v -> navigateToSpecialtyPizza());
        buildCard.setOnClickListener(v -> navigateToBuildYourOwn());
        currentOrderCard.setOnClickListener(v -> navigateToCurrentOrder());
        storeOrderCard.setOnClickListener(v -> navigateToStoreOrder());
    }

    private void navigateToSpecialtyPizza() {
        Intent intent = new Intent(this, SpecialtyPizzaActivity.class);
        startActivity(intent);
    }

    private void navigateToBuildYourOwn() {
        Intent intent = new Intent(this, BuildYourOwnActivity.class);
        startActivity(intent);
    }

    private void navigateToCurrentOrder() {
        Intent intent = new Intent(this, CurrentOrderActivity.class);
        startActivity(intent);
    }

    private void navigateToStoreOrder() {
        Intent intent = new Intent(this, StoreOrdersActivity.class);
        startActivity(intent);
    }
}

