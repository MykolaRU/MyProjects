package com.example.pizzaproject;

import java.util.ArrayList;
import java.util.List;

public class Order {
    private int orderNumber;
    private ArrayList<Pizza> pizzas;

    /**
     * Constructor for creating an Order object with a specified order number.
     *
     */
    public Order() {
        this.orderNumber = OrderNumberGenerator.getInstance().generateOrderNumber();
        this.pizzas = new ArrayList<Pizza>();
    }

    /**
     * Add a pizza to the order.
     *
     * @param pizza The pizza to be added to the order.
     */
    public void addPizza(Pizza pizza) {
        pizzas.add(pizza);
    }

    /**
     * Remove a pizza from the order.
     *
     * @param pizza The pizza to be removed from the order.
     */
    public void removePizza(Pizza pizza) {
        pizzas.remove(pizza);
    }

    /**
     * Calculate the total price of the order based on the prices of individual pizzas.
     *
     * @return The total price of the order.
     */
    public double getTotalPrice() {
        double total = 0;
        for (Pizza pizza : pizzas) {
            total += pizza.getPrice();
        }
        return total;
    }

    /**
     * Get the order number associated with this order.
     *
     * @return The order number.
     */
    public int getOrderNumber() {
        return orderNumber;
    }

    /**
     * Generate a string representation of the order, including its order number and list of pizzas.
     *
     * @return A string representation of the order.
     */
    @Override
    public String toString() {
        return "Order Number: " + orderNumber + ", Pizzas: " + pizzas;
    }

    public List<Pizza> getPizzas() {
        return pizzas;
    }
    /**
     * Generate a list of string representations of the order details.
     *
     * @return A list of strings representing the order details.
     */
    public List<String> getOrderDetails() {
        List<String> details = new ArrayList<>();
        for (Pizza pizza : pizzas) {
            details.add(pizza.toString());
        }
        double subtotal = getTotalPrice();
        double salesTax = subtotal * 0.0625;
        double total = subtotal + salesTax;
        details.add("Subtotal: $" + String.format("%.2f", subtotal));
        details.add("Sales Tax: $" + String.format("%.2f", salesTax));
        details.add("Total: $" + String.format("%.2f", total));
        return details;
    }
    public void setPizzas(ArrayList<Pizza> newPizzas) {
        this.pizzas = newPizzas;
    }
    /**
     * Remove a pizza from the order by its position in the list.
     *
     * @param index The position of the pizza in the list to be removed.
     */
    public void removePizzaAt(int index) {
        if (index >= 0 && index < pizzas.size()) {
            pizzas.remove(index);
        }
    }

}


