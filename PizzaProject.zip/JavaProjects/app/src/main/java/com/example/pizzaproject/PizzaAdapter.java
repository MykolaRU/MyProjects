package com.example.pizzaproject;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class PizzaAdapter extends RecyclerView.Adapter<PizzaAdapter.PizzaViewHolder> {

    private List<String> pizzaList;
    private int selectedPosition = -1;


    public void setSelectedPosition(int position) {
        this.selectedPosition = position;
        notifyDataSetChanged();
    }

    public int getSelectedPosition() {
        return selectedPosition;
    }

    public void updatePizzaList(List<String> newPizzaList) {
        pizzaList.clear();
        pizzaList.addAll(newPizzaList);
        notifyDataSetChanged(); // Notify the adapter, not the list
    }

    public PizzaAdapter(List<String> pizzaList) {
        this.pizzaList = pizzaList;
    }

    @Override
    public PizzaViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(android.R.layout.simple_list_item_1, parent, false);
        return new PizzaViewHolder(view);
    }

    @Override
    public void onBindViewHolder(PizzaViewHolder holder, int position) {
        String pizza = pizzaList.get(position);
        holder.pizzaTextView.setText(pizza);
        holder.itemView.setBackgroundColor(selectedPosition == holder.getAdapterPosition() ? Color.WHITE : Color.TRANSPARENT);
        holder.itemView.setOnClickListener(v -> {
            if (selectedPosition == holder.getAdapterPosition()) {
                // If the same item is clicked again, deselect it
                selectedPosition = -1;
            } else {
                // Otherwise, select the new item
                selectedPosition = holder.getAdapterPosition();
            }
            notifyDataSetChanged();
        });
    }


    @Override
    public int getItemCount() {
        return pizzaList.size();
    }

    static class PizzaViewHolder extends RecyclerView.ViewHolder {
        TextView pizzaTextView;

        public PizzaViewHolder(View itemView) {
            super(itemView);
            pizzaTextView = itemView.findViewById(android.R.id.text1);
        }
    }
}
