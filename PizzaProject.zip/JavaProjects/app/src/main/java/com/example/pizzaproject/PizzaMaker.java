package com.example.pizzaproject;

import java.util.ArrayList;

public class PizzaMaker {

    /**
     * Creates a pizza of the specified type, size, sauce, extra options, and toppings.
     *
     * @param type The type of pizza to create.
     * @param size The size of the pizza.
     * @param sauce The type of sauce for the pizza.
     * @param extraSauce Indicates if extra sauce is required.
     * @param extraCheese Indicates if extra cheese is required.
     * @param toppings The list of toppings for the pizza.
     * @return The created Pizza object.
     */
    public static Pizza createPizza(String type, Size size, Sauce sauce, boolean extraSauce, boolean extraCheese, ArrayList<Topping> toppings) {
        Pizza pizza = null;

        switch (type.toLowerCase()) {
            case "deluxe":
                pizza = new Deluxe(size, extraSauce, extraCheese); // Assuming Deluxe constructor
                break;
            case "supreme":
                pizza = new Supreme(size, extraSauce, extraCheese); // Assuming Supreme constructor
                break;
            case "meatzza":
                pizza = new Meatzza(size, extraSauce, extraCheese); // Assuming Meatzza constructor
                break;
            case "seafood":
                pizza = new Seafood(size, extraSauce, extraCheese); // Assuming Seafood constructor
                break;
            case "pepperoni":
                pizza = new Pepperoni(size, extraSauce, extraCheese); // Assuming Pepperoni constructor
                break;
            case "surprise1":
                pizza = new Surprise1(size, extraSauce, extraCheese); // Assuming Surprise1 constructor
                break;
            case "surprise2":
                pizza = new Surprise2(size, extraSauce, extraCheese); // Assuming Surprise2 constructor
                break;
            case "surprise3":
                pizza = new Surprise3(size, extraSauce, extraCheese); // Assuming Surprise3 constructor
                break;
            case "surprise4":
                pizza = new Surprise4(size, extraSauce, extraCheese); // Assuming Surprise4 constructor
                break;
            case "surprise5":
                pizza = new Surprise5(size, extraSauce, extraCheese); // Assuming Surprise5 constructor
                break;
            case "build your own":
                pizza = new BuildYourOwn(size, sauce, extraSauce, extraCheese, toppings);
                break;
            default:
                // Handle unknown pizza types
                throw new IllegalArgumentException("Unknown pizza type: " + type);
        }

        return pizza;
    }

}
