package com.example.pizzaproject;

public enum Sauce {
    TOMATO, ALFREDO;
}

