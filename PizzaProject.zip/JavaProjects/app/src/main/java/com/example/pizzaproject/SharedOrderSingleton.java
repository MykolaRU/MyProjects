package com.example.pizzaproject;

import java.util.ArrayList;

public class SharedOrderSingleton {
    private static final SharedOrderSingleton instance = new SharedOrderSingleton();

    private Order currentOrder;
    private StoreOrders storeOrders;

    private SharedOrderSingleton() {
        currentOrder = new Order();
        storeOrders = StoreOrders.getInstance();
    }

    public static SharedOrderSingleton getInstance(){
        return instance;
    }

    // Method to start a new order
    public void startNewOrder() {
        currentOrder = new Order();
    }

    public Order getCurrentOrder() {
        return currentOrder;
    }

    public void setCurrentOrder(Order order) {
        this.currentOrder = order;
    }

    public StoreOrders getStoreOrders() {
        return storeOrders;
    }

    public void setStoreOrders(StoreOrders storeOrders) {
        this.storeOrders = storeOrders;
    }

    // Add current order to store orders and start a new one
    public void finalizeCurrentOrder() {
        storeOrders.addOrder(currentOrder);
        startNewOrder();
    }


}
