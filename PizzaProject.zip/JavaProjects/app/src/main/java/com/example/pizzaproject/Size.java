package com.example.pizzaproject;

public enum Size {
    SMALL, MEDIUM, LARGE;
}
