package com.example.pizzaproject;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.textfield.TextInputEditText;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class SpecialtyPizzaActivity extends AppCompatActivity {

    private RecyclerView toppingRecyclerView;
    private ToppingsAdapter toppingsAdapter;
    private Spinner typeSpinner;
    private Spinner sizeSpinner;
    private TextView sauceTextView, priceTextView ;
    private TextInputEditText quantity;

    private CheckBox extraSauceCheckBox, extraCheeseCheckBox;
    private Sauce currentSauce;
    private Button addToOrderButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.specialtypizza);

        initialize();
        setupSpinnerListener();
    }

    private void initialize() {
        quantity = findViewById(R.id.quantity);
        priceTextView = findViewById(R.id.priceTextView);           // Sets up price view
        sauceTextView = findViewById(R.id.sauceTextView);           // Sets up sauce field
        extraCheeseCheckBox = findViewById(R.id.extraCheese);       // Sets up checkbox for extra cheese
        extraSauceCheckBox = findViewById(R.id.extraSauce);         // Sets up checkbox for extra sauce
        addToOrderButton = findViewById(R.id.addToOrderButton);     // Add to Order Button
        typeSpinner = findViewById(R.id.typeSpinner);               // ComboBox Type
        sizeSpinner = findViewById(R.id.sizeSpinner);               // ComboBox Value

        String[] pizzaTypes = new String[]{"Deluxe", "Supreme", "Seafood", "Meatzza", "Pepperoni", "Surprise1", "Surprise2", "Surprise3", "Surprise4", "Surprise5"};
        ArrayAdapter<String> adapterTypes = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, pizzaTypes);
        typeSpinner.setAdapter(adapterTypes);

        List<String> sizes = new ArrayList<>();
        for (Size size : Size.values()) {
            sizes.add(size.name());
        }

        ArrayAdapter<String> adapterSizes = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, sizes);
        adapterSizes.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sizeSpinner.setAdapter(adapterSizes);
        toppingRecyclerView = findViewById(R.id.toppingList);
        toppingsAdapter = new ToppingsAdapter(new ArrayList<>(), topping -> {
            // No action, no need to do anything
        });
        toppingRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        toppingRecyclerView.setAdapter(toppingsAdapter);
        updatePrice();
    }


    // Changes Topping List based on pizza type
    private void setupSpinnerListener() {
        typeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedPizzaType = (String) parent.getItemAtPosition(position);
                List<Topping> newToppings = getSelectedToppings(selectedPizzaType);
                toppingsAdapter.updateToppings(newToppings);
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        addToOrderButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addToOrder();
            }
        });

    }

    // This method sets up click listeners to update price in real time
    private void updatePrice(){
        typeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                calculatePrice(); // Assuming pizzaTypeSpinner is your Spinner for pizza types
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) { }
        });
        sizeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                calculatePrice();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) { }
        });
        extraSauceCheckBox.setOnCheckedChangeListener((buttonView, isChecked) -> calculatePrice());
        extraCheeseCheckBox.setOnCheckedChangeListener((buttonView, isChecked) -> calculatePrice());

    }

    // Returns a list of string toppings when choosing a specific specialty pizza
    private ArrayList<Topping> getSelectedToppings(String pizzaType) {
        ArrayList<Topping> toppings = new ArrayList<>();

        switch (pizzaType) {
            case "Deluxe":
                toppings = new ArrayList<>(Arrays.asList(Topping.SAUSAGE, Topping.PEPPERONI, Topping.GREEN_PEPPER, Topping.ONION, Topping.MUSHROOM));
                setDeluxe();
                break;
            case "Supreme":
                toppings = new ArrayList<>(Arrays.asList(Topping.SAUSAGE, Topping.PEPPERONI, Topping.GREEN_PEPPER, Topping.ONION, Topping.MUSHROOM, Topping.BLACK_OLIVE, Topping.HAM));
                setSupreme();
                break;
            case "Seafood":
                toppings = new ArrayList<>(Arrays.asList(Topping.SHRIMP, Topping.SQUID, Topping.CRAB_MEAT));
                setSeafood();
                break;
            case "Meatzza":
                toppings = new ArrayList<>(Arrays.asList(Topping.SAUSAGE, Topping.PEPPERONI, Topping.BEEF, Topping.HAM));
                setMeatzza();
                break;
            case "Pepperoni":
                toppings = new ArrayList<>(Collections.singletonList(Topping.PEPPERONI));
                setPepperoni();
                break;
            case "Surprise1":
                setSurprise1();
                toppings = new ArrayList<>(Arrays.asList(Topping.SAUSAGE, Topping.PEPPERONI));
                break;
            case "Surprise2":
                setSurprise2();
                toppings = new ArrayList<>(Arrays.asList(Topping.SHRIMP, Topping.GREEN_PEPPER));
                break;
            case "Surprise3":
                setSurprise3();
                toppings = new ArrayList<>(Arrays.asList(Topping.HAM, Topping.SHRIMP, Topping.MUSHROOM));
                break;
            case "Surprise4":
                setSurprise4();
                toppings = new ArrayList<>(Arrays.asList(Topping.HAM, Topping.SHRIMP, Topping.MUSHROOM, Topping.SAUSAGE, Topping.CRAB_MEAT, Topping.SQUID, Topping.PINEAPPLE, Topping.BEEF));
                break;
            case "Surprise5":
                setSurprise5();
                toppings = new ArrayList<>(Collections.singletonList(Topping.PINEAPPLE));
                break;
            default:
                break;
        }

        return toppings;
    }




    public void setDeluxe() {
        updateToppings(Arrays.asList(Topping.SAUSAGE, Topping.PEPPERONI, Topping.GREEN_PEPPER, Topping.ONION, Topping.MUSHROOM));
        updateSauce(Sauce.TOMATO);
        currentSauce = Sauce.TOMATO;
        updatePizzaImage("Deluxe");
    }

    public void setSupreme() {
        updateToppings(Arrays.asList(Topping.SAUSAGE, Topping.PEPPERONI, Topping.GREEN_PEPPER, Topping.ONION, Topping.MUSHROOM, Topping.BLACK_OLIVE, Topping.HAM));
        updateSauce(Sauce.TOMATO);
        currentSauce = Sauce.TOMATO;
        updatePizzaImage("Supreme");
    }

    public void setSeafood() {
        updateToppings(Arrays.asList(Topping.SHRIMP, Topping.SQUID, Topping.CRAB_MEAT));
        updateSauce(Sauce.ALFREDO);
        currentSauce = Sauce.ALFREDO;
        updatePizzaImage("SeaFood");
    }

    public void setMeatzza() {
        updateToppings(Arrays.asList(Topping.SAUSAGE, Topping.PEPPERONI, Topping.BEEF, Topping.HAM));
        updateSauce(Sauce.TOMATO);
        currentSauce = Sauce.TOMATO;
        updatePizzaImage("Meatzza");
    }

    public void setPepperoni() {
        updateToppings(Arrays.asList(Topping.PEPPERONI));
        updateSauce(Sauce.TOMATO);
        currentSauce = Sauce.TOMATO;
        updatePizzaImage("Pepperoni");
    }
    public void setSurprise1() {
        updateToppings(Arrays.asList(Topping.SAUSAGE, Topping.PEPPERONI));
        updateSauce(Sauce.TOMATO);
        currentSauce = Sauce.TOMATO;
        updatePizzaImage("Surprise1");
    }

    public void setSurprise2() {
        updateToppings(Arrays.asList(Topping.SHRIMP, Topping.GREEN_PEPPER));
        updateSauce(Sauce.TOMATO);
        currentSauce = Sauce.TOMATO;
        updatePizzaImage("Surprise2");
    }

    public void setSurprise3() {
        updateToppings(Arrays.asList(Topping.HAM, Topping.SHRIMP, Topping.MUSHROOM));
        updateSauce(Sauce.TOMATO);
        currentSauce = Sauce.TOMATO;
        updatePizzaImage("Surprise3");
    }

    public void setSurprise4() {
        updateToppings(Arrays.asList(Topping.HAM, Topping.SHRIMP, Topping.MUSHROOM, Topping.SAUSAGE, Topping.CRAB_MEAT, Topping.SQUID, Topping.PINEAPPLE, Topping.BEEF));
        updateSauce(Sauce.TOMATO);
        currentSauce = Sauce.TOMATO;
        updatePizzaImage("Surprise4");
    }

    public void setSurprise5() {
        updateToppings(Collections.singletonList(Topping.PINEAPPLE));
        updateSauce(Sauce.TOMATO);
        currentSauce = Sauce.TOMATO;
        updatePizzaImage("Surprise5");
    }


    private void updateToppings(List<Topping> toppings) {
        List<Topping> toppingNames = new ArrayList<>();
        for (Topping topping : toppings) {
            toppingNames.add(topping);
        }
        toppingsAdapter.updateToppings(toppingNames);
    }


    private void updateSauce(Sauce sauce) {
        sauceTextView.setText(sauce.name());
    }

    private void updatePizzaImage(String pizzaType) {
        // Updates the pizza image based on the pizza type
    }

    private void calculatePrice() {
        try {
            // Retrieve the selected pizza type and size
            String selectedPizzaType = (String) typeSpinner.getSelectedItem();
            String selectedSize = (String) sizeSpinner.getSelectedItem();
            Size size = Size.valueOf(selectedSize.toUpperCase());

            // Check for extra toppings
            boolean extraSauce = extraSauceCheckBox.isChecked();
            boolean extraCheese = extraCheeseCheckBox.isChecked();

            // Get the selected toppings based on pizza type
            ArrayList<Topping> arr = getSelectedToppings(selectedPizzaType);


            // Calculate the price based on these factors
            Pizza pizza = PizzaMaker.createPizza(selectedPizzaType.toLowerCase(), size, currentSauce, extraSauce, extraCheese, arr);
            double price = pizza.getPrice();

            // Display the calculated price
            priceTextView.setText(String.format("$%.2f", price));
        } catch (Exception e) {
            e.printStackTrace(); // Log the exception
        }
    }



    private void addToOrder(){
        try {
            String selectedPizzaType = (String) typeSpinner.getSelectedItem();
            String selectedSize = (String) sizeSpinner.getSelectedItem();
            Size size = Size.valueOf(selectedSize.toUpperCase());
            boolean extraSauce = extraSauceCheckBox.isChecked();
            boolean extraCheese = extraCheeseCheckBox.isChecked();
            ArrayList<Topping> selectedToppings = getSelectedToppings(selectedPizzaType);

            int quantity = Integer.parseInt(this.quantity.getText().toString()); // Retrieve quantity
            Order currentOrder = SharedOrderSingleton.getInstance().getCurrentOrder();

            for (int i = 0; i < quantity; i++) { // Add pizzas based on the quantity
                Pizza pizza = PizzaMaker.createPizza(selectedPizzaType.toLowerCase(), size, currentSauce, extraSauce, extraCheese, selectedToppings);
                currentOrder.addPizza(pizza);
            }
            Toast.makeText(SpecialtyPizzaActivity.this, "Added " + quantity + " pizzas to Order #" + currentOrder.getOrderNumber(), Toast.LENGTH_SHORT).show();
        } catch (NumberFormatException e) {
            Toast.makeText(SpecialtyPizzaActivity.this, "Invalid quantity entered", Toast.LENGTH_SHORT).show();
        }
    }



}

