package com.example.pizzaproject;

import java.util.ArrayList;
import java.util.List;

public class StoreOrders {
    private static StoreOrders instance = new StoreOrders();
    private ArrayList<Order> orders;
    private Order currentOrder;  // Current order being built

    private StoreOrders() {
        orders = new ArrayList<Order>();
        currentOrder = new Order();  // Initialize with a new Order, no argument needed
    }


    public void addOrder(Order order) {
        orders.add(order);
    }

    public void removeOrder(Order order) {
        orders.remove(order);
    }

    public static StoreOrders getInstance() {
        return instance;
    }

    public Order getOrder(int orderNumber) {
        for (Order order : orders) {
            if (order.getOrderNumber() == orderNumber) {
                return order;
            }
        }
        return null;
    }
    // Method to get the list of orders
    public List<Order> getOrders() {
        return new ArrayList<>(orders);  // Return a copy of the orders list
    }
    public Order getCurrentOrder() {
        return currentOrder;
    }

    public void finalizeCurrentOrder() {
        orders.add(currentOrder);  // Add the current order to the list of orders
        currentOrder = new Order();  // Start a new order
    }

    public List<Pizza> getPizzasForOrder(int orderNumber) {
        Order order = getOrder(orderNumber);
        if (order != null) {
            return order.getPizzas();
        } else {
            return new ArrayList<>();  // Return an empty list if no order is found
        }
    }

    public List<Integer> getAllOrderNumbers() {
        List<Integer> orderNumbers = new ArrayList<>();
        for (Order order : orders) {
            orderNumbers.add(order.getOrderNumber());
        }
        return orderNumbers;
    }

    @Override
    public String toString() {
        return "Store Orders: " + orders;
    }
}
