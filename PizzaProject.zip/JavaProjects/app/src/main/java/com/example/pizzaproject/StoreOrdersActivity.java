package com.example.pizzaproject;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class StoreOrdersActivity extends AppCompatActivity {

    private Spinner orderSpinner;
    private RecyclerView listOfPizzaOrders;
    private PizzaAdapter pizzaAdapter;
    private Button cancelOrderButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.storeorders); // Replace with your actual layout name

        orderSpinner = findViewById(R.id.orderSpinner);
        listOfPizzaOrders = findViewById(R.id.listOfPizzaOrders);
        cancelOrderButton = findViewById(R.id.cancelOrderButton);
        initializeSpinner();
        initializeRecyclerView();
        cancelOrder();
    }

    private void initializeSpinner() {
        // Get the singleton instance of StoreOrders
        StoreOrders storeOrders = StoreOrders.getInstance();

        // Uses the instance to call the non-static method
        List<Integer> orderNumbers = storeOrders.getAllOrderNumbers();
        ArrayAdapter<Integer> spinnerAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, orderNumbers);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        orderSpinner.setAdapter(spinnerAdapter);

        orderSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                int selectedOrderNumber = (int) parent.getItemAtPosition(position);
                updateRecyclerViewForOrder(selectedOrderNumber);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }


    private void initializeRecyclerView() {
        pizzaAdapter = new PizzaAdapter(new ArrayList<>()); // Initialize with empty list
        listOfPizzaOrders.setAdapter(pizzaAdapter);
        listOfPizzaOrders.setLayoutManager(new LinearLayoutManager(this));
    }

    private void updateRecyclerViewForOrder(int orderNumber) {
        StoreOrders storeOrders = StoreOrders.getInstance();
        Order selectedOrder = storeOrders.getOrder(orderNumber);

        if (selectedOrder != null) {
            List<Pizza> pizzasForOrder = selectedOrder.getPizzas();

            List<String> pizzaDetailsList = new ArrayList<>();
            for (Pizza pizza : pizzasForOrder) {
                pizzaDetailsList.add(pizza.getPizzaDetails()); // Get the detailed description
            }

            pizzaAdapter.updatePizzaList(pizzaDetailsList);
        } else {
            AlertPopUp.showErrorDialog(StoreOrdersActivity.this, "Error! No Pizza Order found");
        }
    }
    private void cancelOrder() {
        cancelOrderButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int selectedOrderIndex = orderSpinner.getSelectedItemPosition();
                if (selectedOrderIndex >= 0) {
                    StoreOrders storeOrders = StoreOrders.getInstance();
                    List<Order> orders = storeOrders.getOrders();

                    // Remove the selected order
                    Order orderToRemove = orders.get(selectedOrderIndex);
                    storeOrders.removeOrder(orderToRemove);

                    // Update Spinner and RecyclerView
                    updateSpinnerAndRecyclerView();
                }
            }
        });
    }
    private void updateSpinnerAndRecyclerView() {
        List<Integer> orderNumbers = StoreOrders.getInstance().getAllOrderNumbers();
        ArrayAdapter<Integer> spinnerAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, orderNumbers);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        orderSpinner.setAdapter(spinnerAdapter);

        // Clear the RecyclerView
        pizzaAdapter.updatePizzaList(new ArrayList<String>());
    }


}

