package com.example.pizzaproject;

import java.util.ArrayList;
import java.util.Arrays;

public class Surprise3 extends Pizza {
    public Surprise3(Size size, Boolean eC, Boolean eS) {
        super(size, Sauce.TOMATO,eS, eC, new ArrayList<Topping>(Arrays.asList(
                Topping.HAM, Topping.SHRIMP, Topping.MUSHROOM)));
    }

    @Override
    public double getPrice() {
        double basePrice = 9.99;  // Base price for Surprise small pizza
        if(this.extraCheese) basePrice+=1;
        if(this.extraSauce) basePrice+=1;
        switch(this.size){
            case LARGE:
                return basePrice + 4.00;
            case MEDIUM:
                return basePrice + 2.00;
            default:
                return basePrice;
        }
    }
}
