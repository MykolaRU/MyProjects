package com.example.pizzaproject;

import java.util.ArrayList;
import java.util.Arrays;

public class Surprise4 extends Pizza {
    public Surprise4(Size size, Boolean eC, Boolean eS) {
        super(size, Sauce.TOMATO,eS, eC, new ArrayList<Topping>(Arrays.asList(
                Topping.HAM, Topping.SHRIMP, Topping.MUSHROOM, Topping.SAUSAGE, Topping.CRAB_MEAT, Topping.SQUID, Topping.PINEAPPLE, Topping.BEEF)));
    }

    @Override
    public double getPrice() {
        double basePrice = 19.99;  // Base price for Surprise small pizza
        if(this.extraCheese) basePrice+=1;
        if(this.extraSauce) basePrice+=1;
        switch(this.size){
            case LARGE:
                return basePrice + 4.00;
            case MEDIUM:
                return basePrice + 2.00;
            default:
                return basePrice;
        }
    }
}