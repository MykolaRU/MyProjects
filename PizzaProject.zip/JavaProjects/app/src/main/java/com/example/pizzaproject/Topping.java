package com.example.pizzaproject;

public enum Topping {
    SAUSAGE, PEPPERONI, GREEN_PEPPER, ONION, MUSHROOM, HAM, BLACK_OLIVE, SHRIMP, SQUID, CRAB_MEATS, PINEAPPLE, BEEF,CRAB_MEAT;
}
