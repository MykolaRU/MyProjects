package com.example.pizzaproject;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

// ToppingsAdapter class extends RecyclerView.Adapter for handling a list of toppings
public class ToppingsAdapter extends RecyclerView.Adapter<ToppingsAdapter.ToppingViewHolder> {

    // List to hold topping data
    private List<String> toppings = new ArrayList<>();
    // Listener for handling click events on toppings
    private OnToppingClickListener listener;
    private int selectedPosition = -1;


    // Constructor for the adapter, initializes the toppings list and click listener
    public ToppingsAdapter(List<String> toppings, OnToppingClickListener listener) {
        this.toppings = toppings;
        this.listener = listener;
    }

    public int getSelectedPosition() {
        return selectedPosition;
    }

    public void resetSelection() {
        selectedPosition = -1;
        notifyDataSetChanged();
    }   // Resets the selection so that only one topping can be selected at a time

    @NonNull
    @Override
    // Creates new ViewHolder for each item in the RecyclerView
    public ToppingViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflates the item layout from XML
        View itemView = LayoutInflater.from(parent.getContext()).inflate(android.R.layout.simple_list_item_1, parent, false);
        // Returns a new ViewHolder instance
        return new ToppingViewHolder(itemView);
    }

    // Click listener is implemented here to handle selection
    @Override
    public void onBindViewHolder(@NonNull ToppingViewHolder holder, int position) {
        String topping = toppings.get(position);
        holder.toppingTextView.setText(topping);

        // Set background color based on selection
        holder.itemView.setBackgroundColor(selectedPosition == holder.getAdapterPosition() ? Color.parseColor("#c8ecf7") : Color.TRANSPARENT);

        // Toggle selection state on click
        holder.itemView.setOnClickListener(v -> {
            if (selectedPosition == holder.getAdapterPosition()) {
                // Deselect if the same item is clicked again
                selectedPosition = -1;
            } else {
                // Select new item
                selectedPosition = holder.getAdapterPosition();
            }
            notifyDataSetChanged();
        });
    }

    public List<String> getToppings() {
        return toppings;
    }



    @Override
    // Returns the total number of items in the list
    public int getItemCount() {
        return toppings.size();
    }


    public void updateToppings(List<Topping> newToppings) {
        // Clears the existing list of toppings
        toppings.clear();
        // Adds each new topping to the list
        for (Topping topping : newToppings) {
            toppings.add(topping.name());
        }
        // Notifies the adapter that the data set has changed
        notifyDataSetChanged();
    }

    // -------------------------------------------------------------------------- ViewHolder class for each item in the RecyclerView
    static class ToppingViewHolder extends RecyclerView.ViewHolder {
        TextView toppingTextView;

        // Constructor for the ViewHolder
        ToppingViewHolder(View itemView) {
            super(itemView);
            // Finds the TextView in the item layout
            toppingTextView = itemView.findViewById(android.R.id.text1);
        }
    }

    // Interface for handling click events on toppings
    public interface OnToppingClickListener {
        void onToppingClick(String topping);
    }
}
